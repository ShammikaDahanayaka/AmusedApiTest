# AmusedApiTest
Amused Group Assignment

# Hybrid automation test framework BBD + DDD
Behavior and Data-Driven test automation framework for assessment

-- In this test framework I used below tech stack --

* Cucumber- test layer
* Authlete- Json Validate
* SpecFlow, RestSharp - api service handler
* C# - primary language
* extentreports - reporting (TestReports/index.html)

## Solution info ##

Testcases :  
https://docs.google.com/spreadsheets/d/1jXeRP3uIfUFG1HGiWzIgAkwEfgc7w2AevxZzVwWuEQY/edit?usp=sharing

###### Prerequisites:
.Net(6.0) Which supports visual studio 2022 

## Run tests:

Build the solution and Run
Execute below command line
>dotnet build  
>dotnet test --logger "console;verbosity=detailed"

![image](https://github.com/ksrajith/AmusedApiTest/assets/16276648/01601313-8eae-438c-9fef-efcc2420a5bc)


## Test Results ##

![AmusedGgroupCNw](https://github.com/ksrajith/AmusedApiTest/assets/16276648/ea4f7ab5-6d07-4316-bd8a-d1c425c95750)
