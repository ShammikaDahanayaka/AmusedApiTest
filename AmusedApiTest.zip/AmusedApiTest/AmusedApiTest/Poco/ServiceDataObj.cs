﻿namespace AmusedApiTest.Poco
{
    public class ServiceDataObj
    {
        public string apiMethod { get; set; }
        public string testCaseName { get; set;}
        public string apiName { get; set; }
        public string urlSuffix { get; set; }
        public string request { get; set; }
        public string response { get; set; }
        public string responseCode { get; set; }
    }
}
