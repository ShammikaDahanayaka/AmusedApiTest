﻿using AmusedApiTest.Poco;

namespace AmusedApiTest.Base
{
    public interface IBaseApiHandler
    {
       public Task ApiRequestResponseHandler();
       public Task<HttpResponseMessage> ApiRequestResponseHandler(ServiceDataObj serviceData);
    }
}
