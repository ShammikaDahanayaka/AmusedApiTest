﻿using AmusedApiTest.Poco;
using AmusedApiTest.Support;
using log4net;
using System.Text;

namespace AmusedApiTest.Base
{
    [Binding]
    class ApiHandler : IBaseApiHandler
    {
        HttpClient client;
        private static readonly ILog _logger = LogManager.GetLogger(typeof(ApiHandler));
        public ApiHandler(){
            client = new HttpClient();
        }

        /// <summary>
        /// Returns Task<HttpResponseMessagev> invoke the api and returns response
        /// <param name="ServiceDataObj"> The ServiceDataObj contains the data from data sheet</param>
        /// </summary>v
        async Task<HttpResponseMessage> IBaseApiHandler.ApiRequestResponseHandler(ServiceDataObj serviceData)
        {
            // assginied the base url
            string url = PropertyFileReader.properties["baseApiurl"];
            // reomove additional shalshes
            if ((url.StartsWith("\"") && url.EndsWith("\"")) ||
                (url.StartsWith("'") && url.EndsWith("'")))
            {
                url = url.Substring(1, url.Length - 2);
            }

            url = url + (serviceData.urlSuffix != null ? serviceData.urlSuffix : "");
            string method = serviceData.apiMethod;
            _logger.Debug("Request Url >>>>>>>>>>" + url);
            if (!string.IsNullOrEmpty(serviceData.request))
            {
                _logger.Debug("Request Body >>>>>>>>>>" + serviceData.request);
            }
            try
            {
                Console.WriteLine("Request Url >>>>>>>>>>" + url);
                switch (method)
                {
                    case "GET":                        
                        return await client.GetAsync(url);

                    case "POST":
                        Console.WriteLine("Request Body >>>>>>>>>>" + serviceData.request);
                        HttpContent content = new StringContent(serviceData.request, Encoding.UTF8, "application/json");
                        return await client.PostAsync(url, content);

                    case "PUT":
                        Console.WriteLine("Request Body >>>>>>>>>>" + serviceData.request);
                        content = new StringContent(serviceData.request, Encoding.UTF8, "application/json");
                        return await client.PutAsync(url, content);

                    case "DELETE":                        
                        return await client.DeleteAsync(url);

                }
            }
            catch (HttpRequestException e)
            {
                _logger.Error(e);
                return null;
            }
            _logger.Error("Request method not executed");
            return null;
        }
        
        Task IBaseApiHandler.ApiRequestResponseHandler()
        {
            return Task.CompletedTask;
        }        

    }
}
