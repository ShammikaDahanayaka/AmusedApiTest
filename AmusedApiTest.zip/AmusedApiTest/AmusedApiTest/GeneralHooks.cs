﻿using AmusedApiTest.Poco;
using AmusedApiTest.Support;
using AventStack.ExtentReports.Gherkin.Model;

namespace AmusedApiTest
{
    [Binding]
    public sealed class GeneralHooks: ExtentReport
    {

        public static Dictionary<string, ServiceDataObj> serviceDataMap;

        [BeforeTestRun]
        public static void TestInitialization()
        {
           // log4net.Config.XmlConfigurator.Configure();
            ExtentReportInit();           
            PropertyFileReader propertyFileReader = new PropertyFileReader();
            propertyFileReader.Read();
            // commented the Excel sheet data reader
           /* DataSheetReader reader = new DataSheetReader();
            serviceDataMap = reader.ExcelRead();*/
        }

        [BeforeFeature]
        public static void BeforeFeature(FeatureContext featureContext)
        {
            _feature = _extentReports.CreateTest<Feature>(featureContext.FeatureInfo.Title);
        }


        [BeforeScenario(Order = 1)]
        public static void FirstBeforeScenario(ScenarioContext scenarioContext)
        {
            _scenario = _feature.CreateNode<Scenario>(scenarioContext.ScenarioInfo.Title);
        }

        [AfterStep]
        public static void AfterStep(ScenarioContext scenarioContext)
        {
            Console.WriteLine("Running after step....");
            string stepType = scenarioContext.StepContext.StepInfo.StepDefinitionType.ToString();
            string stepName = scenarioContext.StepContext.StepInfo.Text;

            //When scenario passed
            if (scenarioContext.TestError == null)
            {
                if (stepType == "Given")
                {
                    _scenario.CreateNode<Given>(stepName);
                }
                else if (stepType == "When")
                {
                    _scenario.CreateNode<When>(stepName);
                }
                else if (stepType == "Then")
                {
                    _scenario.CreateNode<Then>(stepName);
                }
                else if (stepType == "And")
                {
                    _scenario.CreateNode<And>(stepName);
                }
            }

            //When scenario fails
            if (scenarioContext.TestError != null)
            {

                if (stepType == "Given")
                {
                    _scenario.CreateNode<Given>(stepName).Fail(scenarioContext.TestError.Message);
                }
                else if (stepType == "When")
                {
                    _scenario.CreateNode<When>(stepName).Fail(scenarioContext.TestError.Message);
                }
                else if (stepType == "Then")
                {
                    _scenario.CreateNode<Then>(stepName).Fail(scenarioContext.TestError.Message);
                }
                else if (stepType == "And")
                {
                    _scenario.CreateNode<And>(stepName).Fail(scenarioContext.TestError.Message);
                }
            }
        }

        [AfterTestRun]
        public static void AfterScenario()
        {
            ExtentReportTearDown();
        }
    }
}