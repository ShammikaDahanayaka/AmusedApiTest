using AmusedApiTest.Base;
using AmusedApiTest.Poco;
using log4net;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using System.Security.Policy;

namespace AmusedApiTest.StepDefinitions
{
    [Binding]
    public class ApiTestStepDefinitions
    {
        private static readonly ILog logger = LogManager.GetLogger(typeof(ApiTestStepDefinitions));
        ServiceDataObj serviceData;
        HttpResponseMessage response;
        public static string id;

        [Given(@"user invoke ""([^""]*)"" with test case ""([^""]*)""")]
        public void GivenUserInvokeWithTestCase(string method, string testCaseName)
        {
            if (!string.IsNullOrEmpty(method) && !string.IsNullOrEmpty(testCaseName))
            {
                serviceData = new ServiceDataObj();
                serviceData.apiMethod = method;
                serviceData.testCaseName = testCaseName;
                logger.Info("Added testcase :" + testCaseName);
            }
            else
            {
                logger.Error("Error on testcase name :" + testCaseName + " or Method :" + method);
            }

        }

        [When(@"user invoke api with url ""([^""]*)"" with given content for ""([^""]*)""")]
        public void WhenUserInvokeApiWithUrlWithGivenContentFor(string urlSuffix, string testCaseName)
        {
            try
            {
                serviceData.urlSuffix = urlSuffix + id;
                
                serviceData.request = getRequestJson(testCaseName.Substring(0, testCaseName.IndexOf("-")).Trim());
                IBaseApiHandler apiHandler = new ApiHandler();
                response = apiHandler.ApiRequestResponseHandler(serviceData).Result;
                Console.WriteLine("Response Code <<<<<<<<<<<" + (int)response.StatusCode);
                if (!string.IsNullOrEmpty(response.Content.ReadAsStringAsync().Result))
                {
                    Console.WriteLine("Response Body <<<<<<<<<<<" + response.Content.ReadAsStringAsync().Result);
                    logger.Debug("Response Body:" + response.Content.ReadAsStringAsync().Result);
                }
                Assert.IsNotNull(response);
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message);
                Assert.Fail(ex.StackTrace);
            }
        }

        [When(@"user invoke api with url ""([^""]*)"" with given content for ""([^""]*)"" with ""([^""]*)""")]
        public void WhenUserInvokeApiWithUrlWithGivenContentForWith(string urlSuffix, string testCaseName, string jsonBody)
        {
            try
            {
                serviceData.urlSuffix = urlSuffix + id;
                if (string.IsNullOrEmpty(jsonBody))
                {
                    serviceData.request = getRequestJson(testCaseName.Substring(0, testCaseName.IndexOf("-")).Trim());
                }
                else {
                    Console.WriteLine(jsonBody);
                    serviceData.request = jsonBody.Replace("'", "\"");
                    Console.WriteLine(serviceData.request);
                }
                IBaseApiHandler apiHandler = new ApiHandler();
                response = apiHandler.ApiRequestResponseHandler(serviceData).Result;

                if (!string.IsNullOrEmpty(response.Content.ReadAsStringAsync().Result))
                {
                    logger.Debug("Response Body:" + response.Content.ReadAsStringAsync().Result);
                }
                Assert.IsNotNull(response);
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message);
                Assert.Fail(ex.StackTrace);
            }
        }




        [When(@"verify response code as ""([^""]*)""")]
        public void WhenVerifyResponseCodeAs(int code)
        {
            Assert.AreEqual(code, (int)response.StatusCode);
        }




        [Then(@"verify response body with expectd response for ""([^""]*)""")]
        public void ThenVerifyResponseBodyWithExpectdResponseFor(string testCaseName)
        {
            serviceData.response = getResponseJson(testCaseName.Substring(0, testCaseName.IndexOf("-")).Trim());
            Assert.IsTrue(VerifyPositiveResponse(serviceData), "Positive Response validate error");
        }

        [Then(@"verify negative response body with expectd response for ""([^""]*)""")]
        public void ThenVerifyNegativeResponseBodyWithExpectdResponseFor(string testCaseName)
        {
            serviceData.response = getResponseJson(testCaseName.Substring(0, testCaseName.IndexOf("-")).Trim());
            Assert.IsTrue(VerifyNegativeResponse(serviceData), "Positive Response validate error");
        }


        /// <summary>
        /// Returns true if the validatioin for positive secnario is passed 
        /// else returns false
        /// <param name="ServiceDataObj"> The api test data object</param>
        /// </summary>
        private bool VerifyPositiveResponse(ServiceDataObj serviceObj)
        {
            bool verified = false;
            dynamic jsnResponse = JsonConvert.DeserializeObject(response.Content.ReadAsStringAsync().Result);
            string method = serviceObj.apiMethod;

            switch (method)
            {
                case "GET":
                    if (serviceData.testCaseName.EndsWith("SINGLE OBJECT"))
                    {
                        if (jsnResponse["id"] != null && jsnResponse["name"] != null && jsnResponse["data"] != null)
                        {
                            verified = true;
                        }
                        else
                        {
                            verified = false;
                        }
                    }
                    else
                    {
                        foreach (var detail in jsnResponse)
                        {
                            if (detail["id"] != null && detail["name"] != null && detail["data"] != null)
                            {
                                verified = true;
                            }
                            else
                            {
                                verified = false;
                            }

                        }
                    }
                    return verified;
                case "POST":
                    dynamic jsnDataSheet = JsonConvert.DeserializeObject(serviceData.response);
                    id = jsnResponse["id"];
                    ((JValue)jsnResponse.SelectToken("id")).Value = null;
                    ((JValue)jsnDataSheet.SelectToken("id")).Value = null;
                    ((JValue)jsnResponse.SelectToken("createdAt")).Value = null;
                    ((JValue)jsnDataSheet.SelectToken("createdAt")).Value = null;
                    return JToken.DeepEquals(jsnResponse, jsnDataSheet);

                case "PUT":
                    jsnDataSheet = JsonConvert.DeserializeObject(serviceData.response);
                    ((JValue)jsnResponse.SelectToken("id")).Value = null;
                    ((JValue)jsnDataSheet.SelectToken("id")).Value = null;
                    ((JValue)jsnResponse.SelectToken("updatedAt")).Value = null;
                    ((JValue)jsnDataSheet.SelectToken("updatedAt")).Value = null;
                    return JToken.DeepEquals(jsnResponse, jsnDataSheet);

                case "DELETE":
                    jsnDataSheet = JsonConvert.DeserializeObject(serviceData.response);
                    string content = jsnDataSheet["message"];
                    content = content.Replace("$replaceId", id);
                    jsnDataSheet["message"] = content;
                    return JToken.DeepEquals(jsnResponse, jsnDataSheet);
            }
            return verified;

        }

        /// <summary>
        /// Returns true if the validatioin for negative secnario is passed 
        /// else returns false
        /// switch statement can implement futher based on upcomming requirements
        /// <param name="method"> The api method</param>
        /// </summary>
        private bool VerifyNegativeResponse(ServiceDataObj serviceData)
        {
            bool verified = false;
            string method = serviceData.apiMethod;

            switch (method)
            {
                case "GET":
                case "PUT":
                case "DELETE":
                    dynamic jsnResponse = JsonConvert.DeserializeObject(response.Content.ReadAsStringAsync().Result);
                    dynamic jsnDataSheet = JsonConvert.DeserializeObject(serviceData.response);
                    string content = jsnDataSheet["error"];
                    content = content.Replace("$replaceId", serviceData.urlSuffix.Substring(serviceData.urlSuffix.LastIndexOf("/") + 1));
                    jsnDataSheet["error"] = content;
                    return JToken.DeepEquals(jsnResponse, jsnDataSheet);

            }
            return verified;
        }

        // TODO move below jsons to json files for the future maintenance
        private string getRequestJson(string testCaseId)
        {
            switch (testCaseId)
            {
                case "T0004":
                    return "{\"name\":\"Apple MacBook Pro 16\",\"data\":{\"year\":2019,\"price\":1849.99,\"CPU model\":\"Intel Core i9\",\"Hard disk size\":\"1 TB\"}}";
                case "T0005":
                    return "{\"name\":\"Apple MacBook Pro 16\",\"data\":{\"year\":2019,\"price\":2049.99,\"CPU model\":\"Intel Core i9\",\"Hard disk size\":\"1 TB\",\"color\":\"silver\"}}";
                case "T0009":
                    return "{\"name\":\"Apple MacBook Pro 16\",\"data\":{\"year\":2019,\"price\":2049.99,\"CPU model\":\"Intel Core i9\",\"Hard disk size\":\"1 TB\",\"color\":\"silver\"}}";
                default:
                    return null;
            }
        }

        // TODO move below jsons to json files for the future maintenance
        private string getResponseJson(string testCaseId)
        {
            switch (testCaseId)
            {
                case "T0003":
                    return "{\"id\":\"7\",\"name\":\"Apple MacBook Pro 16\",\"data\":{\"year\":2019,\"price\":1849.99,\"CPU model\":\"Intel Core i9\",\"Hard disk size\":\"1 TB\"}}";
                case "T0004":
                    return "{\"id\":\"7\",\"name\":\"Apple MacBook Pro 16\",\"data\":{\"year\":2019,\"price\":1849.99,\"CPU model\":\"Intel Core i9\",\"Hard disk size\":\"1 TB\"},\"createdAt\":\"2022-11-21T20:06:23.986Z\"}";
                case "T0005":
                    return "{\"id\":\"7\",\"name\":\"Apple MacBook Pro 16\",\"data\":{\"year\":2019,\"price\":2049.99,\"CPU model\":\"Intel Core i9\",\"Hard disk size\":\"1 TB\",\"color\":\"silver\"},\"updatedAt\":\"2022-12-25T21:08:41.986Z\"}";
                case "T0006":
                    return "{\"message\":\"Object with id = $replaceId has been deleted.\"}";
                case "T0007":
                    return "{\"error\": \"Oject with id=$replaceId was not found.\"}";
                case "T0009":
                    return "{\"error\": \"The Object with id = $replaceId doesn't exist. Please provide an object id which exists or generate a new Object using POST request and capture the id of it to use it as part of PUT request after that.\"}";
                case "T00010":
                    return "{\"error\": \"Object with id = $replaceId doesn't exist.\"}";
                default:
                    return null;
            }
        }

    }
}